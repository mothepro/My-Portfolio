<?php

// Passwort f�r die Authentifizierung
$passwd = "I_h8_teddy-DDNN";

if (array_key_exists("date",$_GET))
  $t = $_GET["date"];
else
  $t = "";

function write_int($h,$int,$bytes) {
  if ($bytes > 0) {
    fwrite($h,chr(($int>>(8*$bytes-8))%256));
    write_int($h,$int,$bytes-1);
  }
}

function out_int($int,$bytes) {
  $code = "0123456789ABCDEF";
  if ($bytes > 0) {
    $c = ($int>>(8*$bytes-8))%256;
    echo $code{$c>>4}.$code{$c%16};
    out_int($int,$bytes-1);
  }
}

function read_int($h,$bytes) {
  if ($bytes == 0)
    return 0;
  return (ord(fread($h,1))<<(8*$bytes-8))+read_int($h,$bytes-1);
}

function list_write($file,&$data) {
  $h = fopen($file,"wb");
  $y = count($data);
  if ($y > 0)
    $x = count($data[0]);
  else
    $x = 0;
  write_int($h,$y,4);
  write_int($h,$x,4);
  for ($j = 0; $j < $y; $j++)
    for ($i = 0; $i < $x; $i++) {
      write_int($h,strlen($data[$j][$i]),2);
      fwrite($h,$data[$j][$i]);
    }
  fclose($h);
}

function list_read($file) {
  if (!is_file($file))
    return array();
  $h = fopen($file,"rb");
  $data = array();
  $y = read_int($h,4);
  $x = read_int($h,4);
  for ($j = 0; $j < $y; $j++)
    for ($i = 0; $i < $x; $i++) {
      $n = read_int($h,2);
      if ($n > 0)
        $data[$j][$i] = fread($h,$n);
      else
        $data[$j][$i] = "";
    }
  fclose($h);
  return $data;
}

function list_out($data) {
  global $t;
  $y = count($data);
  if ($y > 0)
    $x = count($data[0]);
  else
    $x = 0;
  out_int($y,4);
  out_int($x,4);
  for ($j = 0; $j < $y; $j++)
    for ($i = 0; $i < $x; $i++) {
      if ($i == 2)
        $str = date($t,$data[$j][$i]);
      else
        $str = $data[$j][$i];
      out_int(strlen($str),2);
      echo $str;
    }
}

function highscore($dir,$m) {
  global $passwd;
  $data = list_read("score.data");
  if (array_key_exists("name",$_GET) && array_key_exists("score",$_GET) && array_key_exists("key",$_GET)) {
    if (md5($_GET["name"].$_GET["score"].$passwd) == $_GET["key"]) {
      $n = count($data);
      $i = -1;
      for ($i = 0; $i < $n; $i++)
        if ($data[$i][1]*$dir < $_GET["score"]*$dir) {
          $i--;
          break;
        }
      array_splice($data,$i+1,0,array(array($_GET["name"],$_GET["score"],time())));
      if (count($data) > $m)
        array_splice($data,$m);
      list_write("score.data",$data);
      echo "0";
    }
    else
      echo "1";
  }
  else
    echo "2";
  list_out($data);
}

// Parameter 1 : gibt auf oder absteigende Sortierung an (1 f�r absteigend, -1 f�r aufsteigend)
//   absteigend z.B. f�r Punkte, aufsteigend z.B. f�r Bestzeiten
// Parameter 2 : maximale Eintr�ge der Liste (z.B. 10 oder 100)
highscore(1,30);

?>